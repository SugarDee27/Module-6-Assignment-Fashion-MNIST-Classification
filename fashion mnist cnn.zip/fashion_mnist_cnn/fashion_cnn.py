
import os
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers, models

OUT_DIR = os.path.join(os.path.dirname(__file__), "outputs")
os.makedirs(OUT_DIR, exist_ok=True)

CLASS_NAMES = ["T-shirt/top","Trouser","Pullover","Dress","Coat","Sandal","Shirt","Sneaker","Bag","Ankle boot"]

def load_data():
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.fashion_mnist.load_data()
    x_train = (x_train.astype("float32")/255.0)[..., None]
    x_test = (x_test.astype("float32")/255.0)[..., None]
    return (x_train, y_train), (x_test, y_test)

def build_model():
    model = models.Sequential([
        layers.Conv2D(32,(3,3),activation="relu",padding="same",input_shape=(28,28,1)),
        layers.Conv2D(64,(3,3),activation="relu",padding="same"),
        layers.MaxPooling2D((2,2)),
        layers.Flatten(),
        layers.Dense(128,activation="relu"),
        layers.Dense(10,activation="softmax")
    ])
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    return model

def plot_history(history, out_path):
    plt.figure()
    plt.plot(history.history["accuracy"], label="train_acc")
    if "val_accuracy" in history.history:
        plt.plot(history.history["val_accuracy"], label="val_acc")
    plt.xlabel("Epoch"); plt.ylabel("Accuracy"); plt.title("Training History"); plt.legend()
    plt.tight_layout(); plt.savefig(out_path, dpi=180); plt.close()

def predict_two_samples(model, x_test, y_test, indices=None):
    if indices is None:
        indices = [0,1]
    x_sel = x_test[indices]
    probs = model.predict(x_sel, verbose=0)
    preds = np.argmax(probs, axis=1)
    fig, axes = plt.subplots(1, len(indices), figsize=(6,3))
    if len(indices) == 1: axes=[axes]
    for ax, i, p in zip(axes, indices, preds):
        ax.imshow(x_test[i].squeeze(), cmap="gray"); ax.axis("off")
        ax.set_title(f"pred: {CLASS_NAMES[p]}\ntrue: {CLASS_NAMES[y_test[i]]}")
    out_path = os.path.join(OUT_DIR, "sample_predictions.png")
    plt.tight_layout(); plt.savefig(out_path, dpi=180); plt.close()
    print(f"Saved sample predictions to: {out_path}")

def train(epochs=5, batch_size=128, validation_split=0.1):
    (x_train, y_train), (x_test, y_test) = load_data()
    model = build_model()
    history = model.fit(x_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=validation_split, verbose=2)
    test_loss, test_acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"Test accuracy: {test_acc:.4f}")
    model_path = os.path.join(OUT_DIR, "fashion_cnn.h5"); model.save(model_path)
    print(f"Saved model to: {model_path}")
    hist_path = os.path.join(OUT_DIR, "training_history.png"); plot_history(history, hist_path)
    print(f"Saved training history plot to: {hist_path}")
    predict_two_samples(model, x_test, y_test)

if __name__ == "__main__":
    train()
