
library(keras)
c(c(x_train, y_train), c(x_test, y_test)) %<-% dataset_fashion_mnist()
x_train <- x_train / 255; x_test <- x_test / 255
x_train <- array_reshape(x_train, c(nrow(x_train),28,28,1))
x_test  <- array_reshape(x_test,  c(nrow(x_test),28,28,1))

model <- keras_model_sequential() |>
  layer_conv_2d(32, c(3,3), activation="relu", padding="same", input_shape=c(28,28,1)) |>
  layer_conv_2d(64, c(3,3), activation="relu", padding="same") |>
  layer_max_pooling_2d(c(2,2)) |>
  layer_flatten() |>
  layer_dense(128, activation="relu") |>
  layer_dense(10, activation="softmax")

model |> compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics="accuracy")
history <- model |> fit(x_train, y_train, epochs=5, batch_size=128, validation_split=0.1, verbose=2)
score <- model |> evaluate(x_test, y_test, verbose=0)
cat(sprintf("Test accuracy: %.4f\n", score["accuracy"]))

idx <- c(1,2)
preds <- model |> predict(x_test[idx,,,], verbose=0)
pred_labels <- apply(preds, 1, which.max) - 1L
cat("Predicted labels for first two test images:", pred_labels, "\n")

dir.create("outputs", showWarnings = FALSE)
save_model_hdf5(model, filepath = file.path("outputs", "fashion_cnn_r.h5"))
